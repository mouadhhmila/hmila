//
//  RegionTableViewCell.swift
//  Ambulance
//
//  Created by Imac on 07/12/2018.
//  Copyright © 2018 Imac. All rights reserved.
//

import UIKit

class RegionTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var lab_reg: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
